from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Exam, ExamAttempt, Answer
from questionbank.models import Question
import random


# ========================
# Exam List (Student)
# ========================
@login_required
def exam_list(request):

    exams = Exam.objects.all()

    return render(request, "exam_list.html", {
        "exams": exams
    })


# ========================
# Start Exam (UPDATED 🔥)
# ========================
@login_required
def start_exam(request, exam_id):

    exam = get_object_or_404(Exam, id=exam_id)

    # 🔍 Get all questions from that bank
    all_questions = list(
        Question.objects.filter(bank=exam.question_bank)
    )

    print("TOTAL QUESTIONS IN BANK:", len(all_questions))
    print("EXAM NEEDS:", exam.total_questions)

    # 🚨 SAFETY CHECK (IMPORTANT)
    if len(all_questions) < exam.total_questions:
        messages.error(request, "Not enough questions in this Question Bank!")
        return redirect('exam_list')

    # 🎯 Random selection
    selected_questions = random.sample(all_questions, exam.total_questions)

    # Create attempt
    attempt = ExamAttempt.objects.create(
        student=request.user,
        exam=exam,
        total_questions=len(selected_questions)
    )

    # 🔥 Save selected questions (MOST IMPORTANT)
    attempt.questions.set(selected_questions)

    return render(request, "exam_page.html", {
        "exam": exam,
        "questions": selected_questions,
        "attempt": attempt
    })


# ========================
# Submit Exam (UPDATED 🔥)
# ========================
@login_required
def submit_exam(request, attempt_id):

    attempt = get_object_or_404(ExamAttempt, id=attempt_id)

    # 🔥 Use saved questions (NO FILTER AGAIN)
    questions = attempt.questions.all()

    correct = 0
    wrong = 0
    unanswered = 0

    for q in questions:

        selected = request.POST.get(str(q.id))

        if not selected:
            unanswered += 1
            is_correct = False

        elif selected == q.correct_option:
            correct += 1
            is_correct = True

        else:
            wrong += 1
            is_correct = False

        Answer.objects.create(
            attempt=attempt,
            question=q,
            selected_option=selected if selected else "",
            is_correct=is_correct
        )

    # Save result
    attempt.correct = correct
    attempt.wrong = wrong
    attempt.unanswered = unanswered
    attempt.score = correct
    attempt.save()

    return redirect("exam_result", attempt_id=attempt.id)


# ========================
# Result Page
# ========================
@login_required
def exam_result(request, attempt_id):

    attempt = get_object_or_404(ExamAttempt, id=attempt_id)

    answers = Answer.objects.filter(attempt=attempt)

    return render(request, "exam_result.html", {
        "attempt": attempt,
        "answers": answers
    })


# ========================
# Teacher Dashboard
# ========================
@login_required
def teacher_exam_list(request):

    exams = Exam.objects.all()

    return render(request, "teacher_exam_list.html", {
        "exams": exams
    })